#ifndef BOARD_PORT_H
#define BOARD_PORT_H

#include "port_types.h"

/* All functions except the hardware tick ISR run in ONE main task. */
void board_init(void);
void board_tick_init(void);

/* Monotonic unsigned milliseconds, wraps at 2^32. Atomic snapshot required.
 * Do not reset this clock while uip_port is running. */
u32_t board_millis(void);

/* Optional low-power idle; must wake for RX or tick. May simply return. */
void board_idle(void);

/* Return 0 on success, negative on failure. Configure the supplied MAC. */
int board_nic_init(const u8_t mac[6]);

/* NONBLOCKING: receive at most ONE complete, untagged Ethernet frame.
 * Copy starting at destination MAC; omit preamble, NIC headers and FCS.
 * Never write more than capacity bytes. Return actual length, or 0 if none.
 * Bad/oversize frames: discard the ENTIRE frame and return 0; no truncation.
 * The NIC driver must release/advance its RX descriptor after a discard. */
u16_t board_nic_read(u8_t *frame, u16_t capacity);

/* Return 0 on success, negative on failure. frame is contiguous here.
 * Before returning, copy ALL bytes to private NIC memory or complete DMA.
 * Never leave an asynchronous transfer reading uip_buf after return.
 * Hardware/driver adds minimum Ethernet padding and FCS, not uIP.
 * Bound any wait; a failed send is treated as packet loss by TCP. */
int board_nic_send(const u8_t *frame, u16_t length);

#endif
