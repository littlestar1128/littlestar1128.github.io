#include "board_port.h"
#include "port_config.h"

#if !BOARD_PORT_IMPLEMENTED
#error "TODO_HW: implement port/board_port.c, then set BOARD_PORT_IMPLEMENTED=1"
#endif

/* TODO_HW: add your device header, SPI/Ethernet HAL and GPIO definitions.
 * A Cortex-M/SysTick-style sketch follows. It is NOT a specific BSP. */
static volatile u32_t tick_ms;

void board_init(void)
{
  /* TODO_HW: clock tree, pin multiplexing, GPIO, SPI/EMAC, caches if any. */
}

void board_tick_init(void)
{
  tick_ms = 0;
  /* TODO_HW: configure a hardware timer interrupt EXACTLY every 1 ms.
   * Hook the handler below into the real vector; enable the interrupt.
   * If using a vendor HAL tick, reuse that tick and remove tick_ms here.
   * Do not initialize a competing SysTick handler twice. */
}

/* TODO_HW: rename/register this handler and clear the timer IRQ flag.
 * Do NOT call uip_input/uip_periodic/the echo app from this ISR. */
void BOARD_TICK_IRQHandler(void)
{
  /* TODO_HW: acknowledge the interrupt if the peripheral requires it. */
  ++tick_ms;
}

u32_t board_millis(void)
{
  /* TODO_HW: 8/16-bit MCUs need a critical section for this 32-bit read.
   * Save interrupt state -> disable -> snapshot -> restore PREVIOUS state.
   * On suitable aligned 32-bit MCUs this load is naturally atomic.
   * If the timer period is not 1 ms, convert ticks to milliseconds. */
  return tick_ms;
}

void board_idle(void)
{
  /* TODO_HW optional: watchdog service / low-power idle. No long delay. */
}

int board_nic_init(const u8_t mac[6])
{
  (void)mac;
  /* TODO_HW: reset NIC, verify ID, configure SPI/MAC/PHY and RX/TX RAM.
   * Program mac[0..5], select correct filters, enable RX.
   * For ENC28J60: also implement SPI access and RX-ring errata handling.
   * Change to return 0 only when initialization has really succeeded. */
  return -1;
}

u16_t board_nic_read(u8_t *frame, u16_t capacity)
{
  (void)frame;
  (void)capacity;
  /* TODO_HW: poll RX -> verify frame/status/length -> bounded copy.
   * Remove FCS if the NIC includes it in the reported length.
   * Drop bad/oversize frames completely, then release RX storage. */
  return 0;
}

int board_nic_send(const u8_t *frame, u16_t length)
{
  (void)frame;
  (void)length;
  /* TODO_HW: bounded synchronous copy/send, padding + hardware CRC.
   * DMA: wait for completion or copy to a driver-owned TX buffer.
   * Change to return 0 only when the frame has been accepted. */
  return -1;
}
