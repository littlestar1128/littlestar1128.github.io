"""Verify the MCU echo server without using TCP half-close."""
import argparse
import socket


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("host", nargs="?", default="192.168.1.50")
    parser.add_argument("--port", type=int, default=1234)
    parser.add_argument("--bytes", type=int, default=4096, dest="byte_count")
    args = parser.parse_args()
    if args.byte_count < 1:
        parser.error("--bytes must be positive")
    completed = 0
    with socket.create_connection((args.host, args.port), timeout=10) as sock:
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        while completed < args.byte_count:
            count = min(256, args.byte_count - completed)
            expected = bytes((completed + i) % 256 for i in range(count))
            sock.sendall(expected)
            received = bytearray()
            while len(received) < count:
                chunk = sock.recv(count - len(received))
                if not chunk:
                    raise RuntimeError("Connection closed before full echo")
                received.extend(chunk)
            if received != expected:
                raise RuntimeError(f"Echo mismatch near byte {completed}")
            completed += count
        # Stock uIP 1.0: receive all echoed bytes before close.
        # Do not call shutdown(SHUT_WR) before receiving the echo.
    print(f"PASS: {completed} binary bytes echoed by {args.host}:{args.port}")


if __name__ == "__main__":
    main()
