#include "uip_port.h"
#include "board_port.h"

int main(void)
{
  if(uip_port_init() < 0) {
    /* TODO_HW: report NIC initialization failure (LED/UART/watchdog policy). */
    for(;;) {
      board_idle();
    }
  }
  for(;;) {
    uip_port_run_once();
    board_idle();
  }
}
