/*
 * Packet-level host tests against uIP 1.0 plus the documented ARP wrap fix.
 * No sockets, OS network stack, target board or network access is involved.
 * The board functions below replace port/board_port.c at link time.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "uip.h"
#include "uip_arp.h"
#include "uip_port.h"
#include "board_port.h"
#include "port_config.h"

#define CHECK(condition) do { \
  if(!(condition)) { \
    fprintf(stderr, "FAIL %s:%d: %s\n", __FILE__, __LINE__, #condition); \
    exit(1); \
  } \
} while(0)

#define ETH_SIZE 14u
#define IP_SIZE 20u
#define TCP_SIZE 20u
#define TCP_FIN_FLAG 0x01u
#define TCP_SYN_FLAG 0x02u
#define TCP_ACK_FLAG 0x10u
#define TCP_PSH_FLAG 0x08u
#define FRAME_CAPACITY UIP_BUFSIZE
#define TX_CAPACITY 16u

struct packet {
  u8_t data[FRAME_CAPACITY];
  u16_t len;
};

struct peer {
  u16_t port;
  u16_t mss;
  u32_t seq;
  u32_t ack;
};

static const u8_t local_mac[6] = {2, 0, 0, 0, 0, 0x50};
static const u8_t remote_mac[6] = {2, 0, 0, 0, 0, 1};
static const u8_t local_ip[4] = {192, 168, 1, 50};
static const u8_t remote_ip[4] = {192, 168, 1, 1};
static struct packet input;
static struct packet output[TX_CAPACITY];
static unsigned output_count;
static u32_t now_ms;
static int nic_init_result;
static unsigned nic_reads;
static unsigned init_calls;
static unsigned tick_init_calls;
static unsigned test_count;
/* Only the first two regression groups use this clock. The original ARP
 * clock starts at BSS zero and uip_arp_init() deliberately does NOT reset it.
 * Keep these groups before any port-driven ARP timer calls in main(). */
static u8_t expected_arp_clock;

/* Fake target board: one complete RX frame, copied synchronously on TX. */
void board_init(void) { ++init_calls; }
void board_tick_init(void) { ++tick_init_calls; }
u32_t board_millis(void) { return now_ms; }
void board_idle(void) { }

int
board_nic_init(const u8_t mac[6])
{
  CHECK(memcmp(mac, local_mac, sizeof(local_mac)) == 0);
  return nic_init_result;
}

u16_t
board_nic_read(u8_t *frame, u16_t capacity)
{
  u16_t len;
  ++nic_reads;
  len = input.len;
  CHECK(len <= capacity);
  if(len != 0) {
    memcpy(frame, input.data, len);
    input.len = 0;
  }
  return len;
}

int
board_nic_send(const u8_t *frame, u16_t length)
{
  CHECK(length <= FRAME_CAPACITY);
  CHECK(output_count < TX_CAPACITY);
  output[output_count].len = length;
  memcpy(output[output_count].data, frame, length);
  ++output_count;
  return 0;
}

static u16_t
read16(const u8_t *p)
{
  return (u16_t)(((u16_t)p[0] << 8) | p[1]);
}

static u32_t
read32(const u8_t *p)
{
  return ((u32_t)p[0] << 24) | ((u32_t)p[1] << 16) |
         ((u32_t)p[2] << 8) | (u32_t)p[3];
}

static void
write16(u8_t *p, u16_t value)
{
  p[0] = (u8_t)(value >> 8);
  p[1] = (u8_t)value;
}

static void
write32(u8_t *p, u32_t value)
{
  p[0] = (u8_t)(value >> 24);
  p[1] = (u8_t)(value >> 16);
  p[2] = (u8_t)(value >> 8);
  p[3] = (u8_t)value;
}

static u32_t
checksum_sum(const u8_t *data, unsigned len, u32_t sum)
{
  while(len >= 2) {
    sum += read16(data);
    data += 2;
    len -= 2;
  }
  if(len != 0) {
    sum += (u16_t)((u16_t)data[0] << 8);
  }
  return sum;
}

static u16_t
checksum_finish(u32_t sum)
{
  while(sum >> 16) {
    sum = (sum & 0xffffUL) + (sum >> 16);
  }
  return (u16_t)~sum;
}

static u16_t
tcp_checksum(const u8_t *ip)
{
  unsigned tcp_len;
  u32_t sum;
  tcp_len = read16(ip + 2) - IP_SIZE;
  sum = checksum_sum(ip + 12, 8, 0);
  sum += 6u + tcp_len;
  return checksum_finish(checksum_sum(ip + IP_SIZE, tcp_len, sum));
}

static void
clear_output(void)
{
  output_count = 0;
}

static void
reset_at(u32_t time_ms)
{
  now_ms = time_ms;
  input.len = 0;
  clear_output();
  nic_init_result = 0;
  nic_reads = 0;
  init_calls = 0;
  tick_init_calls = 0;
  CHECK(uip_port_init() == 0);
  CHECK(init_calls == 1);
  CHECK(tick_init_calls == 1);
}

static void
set_ethernet(u8_t *frame, u16_t type)
{
  memcpy(frame, local_mac, 6);
  memcpy(frame + 6, remote_mac, 6);
  write16(frame + 12, type);
}

static void
inject_arp_request_from(u8_t host)
{
  u8_t *arp;
  CHECK(input.len == 0);
  memset(input.data, 0, sizeof(input.data));
  set_ethernet(input.data, 0x0806);
  memset(input.data, 0xff, 6);
  arp = input.data + ETH_SIZE;
  write16(arp, 1);
  write16(arp + 2, 0x0800);
  arp[4] = 6;
  arp[5] = 4;
  write16(arp + 6, 1);
  memcpy(arp + 8, remote_mac, 6);
  arp[8 + 5] = host;
  memcpy(arp + 14, remote_ip, 4);
  arp[14 + 3] = host;
  memcpy(arp + 24, local_ip, 4);
  input.len = ETH_SIZE + 28;
  uip_port_run_once();
}

static void
inject_arp_request(void)
{
  inject_arp_request_from(remote_ip[3]);
}

static void
prime_arp(void)
{
  clear_output();
  inject_arp_request();
  CHECK(output_count == 1);
  CHECK(output[0].len == ETH_SIZE + 28);
  CHECK(read16(output[0].data + 12) == 0x0806);
  CHECK(read16(output[0].data + ETH_SIZE + 6) == 2);
  CHECK(memcmp(output[0].data, remote_mac, 6) == 0);
  CHECK(memcmp(output[0].data + 6, local_mac, 6) == 0);
  CHECK(memcmp(output[0].data + ETH_SIZE + 14, local_ip, 4) == 0);
  clear_output();
}

static void
inject_tcp(const struct peer *peer, u8_t flags, const u8_t *data,
           u16_t length, u16_t window)
{
  u8_t *ip;
  u8_t *tcp;
  unsigned tcp_header;
  unsigned ip_len;
  CHECK(input.len == 0);
  tcp_header = TCP_SIZE + ((flags & TCP_SYN_FLAG) ? 4u : 0u);
  ip_len = IP_SIZE + tcp_header + length;
  CHECK(ETH_SIZE + ip_len <= FRAME_CAPACITY);
  memset(input.data, 0, sizeof(input.data));
  set_ethernet(input.data, 0x0800);
  ip = input.data + ETH_SIZE;
  tcp = ip + IP_SIZE;
  ip[0] = 0x45;
  write16(ip + 2, (u16_t)ip_len);
  ip[8] = 64;
  ip[9] = 6;
  memcpy(ip + 12, remote_ip, 4);
  memcpy(ip + 16, local_ip, 4);
  write16(ip + 10, checksum_finish(checksum_sum(ip, IP_SIZE, 0)));
  write16(tcp, peer->port);
  write16(tcp + 2, ECHO_PORT);
  write32(tcp + 4, peer->seq);
  write32(tcp + 8, peer->ack);
  tcp[12] = (u8_t)((tcp_header / 4u) << 4);
  tcp[13] = flags;
  write16(tcp + 14, window);
  if(flags & TCP_SYN_FLAG) {
    tcp[20] = 2;
    tcp[21] = 4;
    write16(tcp + 22, peer->mss);
  }
  if(length != 0) {
    memcpy(tcp + tcp_header, data, length);
  }
  write16(tcp + 16, tcp_checksum(ip));
  input.len = (u16_t)(ETH_SIZE + ip_len);
  uip_port_run_once();
}

static const u8_t *
checked_tcp(unsigned index)
{
  const u8_t *frame;
  const u8_t *ip;
  CHECK(index < output_count);
  frame = output[index].data;
  CHECK(output[index].len >= ETH_SIZE + IP_SIZE + TCP_SIZE);
  CHECK(read16(frame + 12) == 0x0800);
  CHECK(memcmp(frame, remote_mac, 6) == 0);
  CHECK(memcmp(frame + 6, local_mac, 6) == 0);
  ip = frame + ETH_SIZE;
  CHECK(ip[0] == 0x45);
  CHECK(ip[9] == 6);
  CHECK(read16(ip + 2) + ETH_SIZE == output[index].len);
  CHECK(memcmp(ip + 12, local_ip, 4) == 0);
  CHECK(memcmp(ip + 16, remote_ip, 4) == 0);
  CHECK(checksum_finish(checksum_sum(ip, IP_SIZE, 0)) == 0);
  CHECK(tcp_checksum(ip) == 0);
  return ip + IP_SIZE;
}

static unsigned
payload_length(const u8_t *tcp)
{
  return read16(tcp - IP_SIZE + 2) - IP_SIZE - (unsigned)(tcp[12] >> 4) * 4u;
}

static const u8_t *
payload(const u8_t *tcp)
{
  return tcp + (unsigned)(tcp[12] >> 4) * 4u;
}

static struct uip_conn *
connection(const struct peer *peer)
{
  unsigned i;
  for(i = 0; i < UIP_CONNS; ++i) {
    if(uip_conns[i].rport == HTONS(peer->port) &&
       (uip_conns[i].tcpstateflags & UIP_TS_MASK) != UIP_CLOSED) {
      return &uip_conns[i];
    }
  }
  CHECK(0);
  return NULL;
}

static struct peer
connect_peer(u16_t port, u16_t mss)
{
  struct peer peer;
  const u8_t *tcp;
  peer.port = port;
  peer.mss = mss;
  peer.seq = 0x12340000UL + port;
  peer.ack = 0;
  clear_output();
  inject_tcp(&peer, TCP_SYN_FLAG, NULL, 0, 4096);
  CHECK(output_count == 1);
  tcp = checked_tcp(0);
  CHECK((tcp[13] & 0x17u) == (TCP_SYN_FLAG | TCP_ACK_FLAG));
  CHECK(read16(tcp) == ECHO_PORT);
  CHECK(read16(tcp + 2) == port);
  CHECK(read32(tcp + 8) == peer.seq + 1);
  peer.seq += 1;
  peer.ack = read32(tcp + 4) + 1;
  clear_output();
  inject_tcp(&peer, TCP_ACK_FLAG, NULL, 0, 4096);
  CHECK((connection(&peer)->tcpstateflags & UIP_TS_MASK) == UIP_ESTABLISHED);
  CHECK(connection(&peer)->mss == mss);
  clear_output();
  return peer;
}

static const u8_t *
expect_echo(struct peer *peer, const u8_t *expected, unsigned length)
{
  const u8_t *tcp;
  CHECK(output_count == 1);
  tcp = checked_tcp(0);
  CHECK((tcp[13] & (TCP_ACK_FLAG | TCP_PSH_FLAG)) ==
        (TCP_ACK_FLAG | TCP_PSH_FLAG));
  CHECK(read32(tcp + 4) == peer->ack);
  CHECK(read32(tcp + 8) == peer->seq);
  CHECK(payload_length(tcp) == length);
  CHECK(memcmp(payload(tcp), expected, length) == 0);
  peer->ack += length;
  return tcp;
}

static void
acknowledge(struct peer *peer)
{
  clear_output();
  inject_tcp(peer, TCP_ACK_FLAG, NULL, 0, 4096);
}

static void
inject_busy_frame(void)
{
  CHECK(input.len == 0);
  memset(input.data, 0xa5, sizeof(input.data));
  set_ethernet(input.data, 0x88b5); /* Unhandled EtherType, still real RX work. */
  input.len = FRAME_CAPACITY;
  uip_port_run_once();
}

static void
pass(const char *name)
{
  ++test_count;
  printf("PASS %s\n", name);
}

static void
arp_tick(void)
{
  uip_arp_timer();
  expected_arp_clock = (u8_t)(expected_arp_clock + 1u);
}

static void
arp_advance_to(u8_t target)
{
  while(expected_arp_clock != target) {
    arp_tick();
  }
}

static void
learn_arp_host(u8_t host)
{
  clear_output();
  inject_arp_request_from(host);
  CHECK(output_count == 1);
  CHECK(read16(output[0].data + ETH_SIZE + 6) == 2);
  clear_output();
}

/* Probe only the public ARP API, without reading its static table or clock.
 * An IP output keeps its Ethernet type when cached, otherwise becomes ARP. */
static int
arp_has_host(u8_t host)
{
  int cached;
  memset(uip_buf, 0, UIP_BUFSIZE);
  memcpy(uip_buf + ETH_SIZE + 12, local_ip, 4);
  memcpy(uip_buf + ETH_SIZE + 16, remote_ip, 4);
  uip_buf[ETH_SIZE + 16 + 3] = host;
  uip_len = IP_SIZE + TCP_SIZE;
  uip_arp_out();
  cached = (read16(uip_buf + 12) == 0x0800);
  if(cached) {
    CHECK(uip_buf[5] == host);
  } else {
    CHECK(read16(uip_buf + 12) == 0x0806);
    CHECK(read16(uip_buf + ETH_SIZE + 6) == 1);
  }
  uip_len = 0;
  return cached;
}

static void
test_arp_age_across_8bit_wrap(void)
{
  unsigned i;
  reset_at(0);
  arp_advance_to(254);
  learn_arp_host(1);
  for(i = 0; i < UIP_ARP_MAXAGE - 1u; ++i) {
    arp_tick();
  }
  CHECK(arp_has_host(1)); /* Age 119: entry must still be usable. */
  arp_tick();
  CHECK(!arp_has_host(1)); /* Age 120 after 255 -> 0: entry must expire. */
  pass("ARP age across 8-bit wrap: present at 119 ticks, expired at 120");
}

static void
test_arp_oldest_replacement_across_8bit_wrap(void)
{
  unsigned host;
  CHECK(UIP_ARPTAB_SIZE >= 2 && UIP_ARPTAB_SIZE < 250);
  reset_at(0); /* Does not reset expected_arp_clock or the core's arptime. */
  arp_advance_to(254);
  learn_arp_host(1); /* First table slot, to be refreshed after wrap. */
  arp_tick();
  learn_arp_host(2); /* Second slot: this will be the oldest at time zero. */
  arp_tick();
  CHECK(expected_arp_clock == 0);
  learn_arp_host(1); /* Refresh slot zero: age zero, versus slot one's age 1. */
  for(host = 3; host <= UIP_ARPTAB_SIZE; ++host) {
    learn_arp_host((u8_t)host);
  }
  learn_arp_host((u8_t)(UIP_ARPTAB_SIZE + 1u)); /* Full table: force eviction. */
  CHECK(arp_has_host(1)); /* A signed subtraction wrongly evicts slot zero. */
  CHECK(!arp_has_host(2));
  for(host = 3; host <= UIP_ARPTAB_SIZE + 1u; ++host) {
    CHECK(arp_has_host((u8_t)host));
  }
  pass("full ARP table replaces the oldest entry across 255-to-0 wrap");
}

static void
test_initialization_and_short_frames(void)
{
  unsigned reads_before;
  reset_at(0);
  input.len = 13;
  memset(input.data, 0xff, input.len);
  uip_port_run_once();
  CHECK(output_count == 0);
  inject_busy_frame();
  CHECK(output_count == 0);
  nic_init_result = -1;
  CHECK(uip_port_init() < 0);
  reads_before = nic_reads;
  now_ms += PORT_TCP_PERIOD_MS;
  uip_port_run_once();
  CHECK(nic_reads == reads_before);
  CHECK(output_count == 0);
  pass("initialization, short frame, unknown EtherType, NIC failure");
}

static void
test_binary_echo_and_fin(void)
{
  struct peer peer;
  struct uip_conn *conn;
  const u8_t bytes[] = {0, 1, 0xff, 'u', 'I', 'P', 0, '\r', '\n'};
  const u8_t *tcp;
  reset_at(0);
  prime_arp();
  peer = connect_peer(40000, 256);
  inject_tcp(&peer, TCP_ACK_FLAG | TCP_PSH_FLAG, bytes, sizeof(bytes), 4096);
  peer.seq += sizeof(bytes);
  tcp = expect_echo(&peer, bytes, sizeof(bytes));
  CHECK(read16(tcp + 14) == 0); /* Keep copied data until the peer ACKs. */
  acknowledge(&peer);
  CHECK(!uip_stopped(connection(&peer)));
  CHECK(output_count == 1);
  tcp = checked_tcp(0);
  CHECK(payload_length(tcp) == 0);
  CHECK(read16(tcp + 14) != 0);
  clear_output();
  conn = connection(&peer);
  inject_tcp(&peer, TCP_FIN_FLAG | TCP_ACK_FLAG, NULL, 0, 4096);
  ++peer.seq;
  CHECK(output_count == 1);
  tcp = checked_tcp(0);
  CHECK((tcp[13] & 0x17u) == (TCP_FIN_FLAG | TCP_ACK_FLAG));
  CHECK(read32(tcp + 8) == peer.seq);
  CHECK(read32(tcp + 4) == peer.ack);
  ++peer.ack;
  acknowledge(&peer);
  CHECK((conn->tcpstateflags & UIP_TS_MASK) == UIP_CLOSED);
  pass("ARP, handshake, binary echo, window reopen, orderly FIN");
}

static void
test_retransmission_during_busy_rx(void)
{
  struct peer peer;
  const u8_t bytes[] = "persistent bytes survive uip_buf reuse";
  u32_t original_seq;
  const u8_t *tcp;
  unsigned i;
  reset_at(0);
  prime_arp();
  peer = connect_peer(40001, 256);
  inject_tcp(&peer, TCP_ACK_FLAG | TCP_PSH_FLAG, bytes, sizeof(bytes), 4096);
  peer.seq += sizeof(bytes);
  original_seq = peer.ack;
  expect_echo(&peer, bytes, sizeof(bytes));
  clear_output();
  for(i = 0; i < 32 && output_count == 0; ++i) {
    now_ms += PORT_TCP_PERIOD_MS;
    inject_busy_frame();
  }
  CHECK(i < 32);
  CHECK(connection(&peer)->nrtx != 0);
  CHECK(output_count == 1);
  tcp = checked_tcp(0);
  CHECK(read32(tcp + 4) == original_seq);
  CHECK(read32(tcp + 8) == peer.seq);
  CHECK(payload_length(tcp) == sizeof(bytes));
  CHECK(memcmp(payload(tcp), bytes, sizeof(bytes)) == 0);
  acknowledge(&peer);
  CHECK(!uip_stopped(connection(&peer)));
  pass("identical retransmission despite continuous RX and buffer overwrite");
}

static void
test_ack_with_next_payload(void)
{
  struct peer peer;
  const u8_t first[] = "first";
  const u8_t second[] = "second-with-ACK";
  const u8_t *tcp;
  reset_at(0);
  prime_arp();
  peer = connect_peer(40002, 256);
  inject_tcp(&peer, TCP_ACK_FLAG | TCP_PSH_FLAG, first, sizeof(first), 4096);
  peer.seq += sizeof(first);
  expect_echo(&peer, first, sizeof(first));
  clear_output();
  inject_tcp(&peer, TCP_ACK_FLAG | TCP_PSH_FLAG, second, sizeof(second), 4096);
  CHECK(output_count == 1);
  tcp = checked_tcp(0);
  /* Stock 1.0 ignores the new payload while UIP_STOPPED was set. */
  CHECK(read32(tcp + 8) == peer.seq);
  CHECK(payload_length(tcp) == 0);
  CHECK(!uip_stopped(connection(&peer)));
  clear_output();
  /* The peer retransmits its unacknowledged bytes after window reopens. */
  inject_tcp(&peer, TCP_ACK_FLAG | TCP_PSH_FLAG, second, sizeof(second), 4096);
  peer.seq += sizeof(second);
  expect_echo(&peer, second, sizeof(second));
  acknowledge(&peer);
  CHECK(!uip_stopped(connection(&peer)));
  pass("ACK plus next payload: safe window reopen, retransmitted input echoed");
}

static void
test_segmentation_and_two_connections(void)
{
  struct peer peer;
  struct peer other;
  u8_t bytes[180];
  const u8_t other_bytes[] = "separate connection";
  unsigned i;
  unsigned offset;
  unsigned count;
  u8_t timer_a;
  u8_t timer_b;
  reset_at(0);
  prime_arp();
  peer = connect_peer(40003, 64);
  other = connect_peer(40004, 128);
  for(i = 0; i < sizeof(bytes); ++i) {
    bytes[i] = (u8_t)(i ^ 0xa5u);
  }
  inject_tcp(&peer, TCP_ACK_FLAG | TCP_PSH_FLAG, bytes, sizeof(bytes), 4096);
  peer.seq += sizeof(bytes);
  expect_echo(&peer, bytes, 64);
  clear_output();
  inject_tcp(&other, TCP_ACK_FLAG | TCP_PSH_FLAG, other_bytes,
             sizeof(other_bytes), 4096);
  other.seq += sizeof(other_bytes);
  expect_echo(&other, other_bytes, sizeof(other_bytes));
  timer_a = connection(&peer)->timer;
  timer_b = connection(&other)->timer;
  CHECK(timer_a > 0 && timer_b > 0);
  clear_output();
  now_ms += PORT_TCP_PERIOD_MS;
  inject_busy_frame();
  CHECK(connection(&peer)->timer == (u8_t)(timer_a - 1));
  CHECK(connection(&other)->timer == (u8_t)(timer_b - 1));
  acknowledge(&other);
  CHECK(!uip_stopped(connection(&other)));
  offset = 64;
  while(offset < sizeof(bytes)) {
    acknowledge(&peer);
    count = sizeof(bytes) - offset;
    if(count > 64) {
      count = 64;
    }
    expect_echo(&peer, bytes + offset, count);
    offset += count;
  }
  acknowledge(&peer);
  CHECK(!uip_stopped(connection(&peer)));
  CHECK(connection(&peer)->appstate.length == 0);
  CHECK(connection(&other)->appstate.length == 0);
  pass("peer MSS segmentation, separate connection buffers, all timers polled");
}

static void
test_tick_wrap_and_bounded_catchup(void)
{
  struct peer peer;
  struct uip_conn *conn;
  u8_t timer_before;
  unsigned i;
  reset_at(0xfffffff0UL);
  prime_arp();
  peer = connect_peer(40005, 256);
  conn = connection(&peer);
  /* TIME_WAIT has an increasing timer: convenient for exact cadence checks. */
  conn->tcpstateflags = UIP_TIME_WAIT;
  conn->timer = 0;
  now_ms += PORT_TCP_PERIOD_MS - 1u;
  inject_busy_frame();
  CHECK(conn->timer == 0);
  now_ms += 1;
  inject_busy_frame();
  CHECK(conn->timer == 1);
  timer_before = conn->timer;
  now_ms += PORT_TCP_PERIOD_MS * (PORT_TIMER_CATCHUP_LIMIT + 2u);
  inject_busy_frame();
  CHECK(conn->timer == (u8_t)(timer_before + PORT_TIMER_CATCHUP_LIMIT));
  inject_busy_frame(); /* Same clock: retained debt is still processed. */
  CHECK(conn->timer == (u8_t)(timer_before + PORT_TIMER_CATCHUP_LIMIT + 2u));
  for(i = 0; i < 3; ++i) {
    inject_busy_frame();
  }
  CHECK(conn->timer == (u8_t)(timer_before + PORT_TIMER_CATCHUP_LIMIT + 2u));
  pass("32-bit millisecond wrap, 500 ms boundary, bounded catch-up without drift");
}

static void
test_arp_aging_during_busy_rx(void)
{
  struct peer peer;
  unsigned i;
  unsigned catchup;
  reset_at(0);
  prime_arp();
  for(i = 0; i < UIP_ARP_MAXAGE; ++i) {
    now_ms += PORT_ARP_PERIOD_MS;
    clear_output();
    inject_busy_frame();
    /* Drain the bounded 500 ms catch-up debt before creating a SYN below.
     * Each call still has an RX frame, so ARP never depends on idle RX. */
    for(catchup = 0;
        catchup < PORT_ARP_PERIOD_MS / PORT_TCP_PERIOD_MS;
        ++catchup) {
      inject_busy_frame();
    }
  }
  clear_output();
  peer.port = 40006;
  peer.mss = 256;
  peer.seq = 123;
  peer.ack = 0;
  inject_tcp(&peer, TCP_SYN_FLAG, NULL, 0, 4096);
  CHECK(output_count == 1);
  CHECK(read16(output[0].data + 12) == 0x0806);
  CHECK(read16(output[0].data + ETH_SIZE + 6) == 1);
  CHECK(memcmp(output[0].data + ETH_SIZE + 24, remote_ip, 4) == 0);
  pass("ARP cache expires after 120 x 10 s while RX remains busy");
}

int
main(int argc, char **argv)
{
  CHECK(sizeof(u8_t) == 1 && sizeof(u16_t) == 2 && sizeof(u32_t) == 4);
  CHECK(UIP_CONNS >= 2);
  /* Each regression can be run in a fresh process against unpatched 1.0. */
  if(argc == 2) {
    if(strcmp(argv[1], "--arp-wrap-aging") == 0) {
      test_arp_age_across_8bit_wrap();
    } else if(strcmp(argv[1], "--arp-wrap-replacement") == 0) {
      test_arp_oldest_replacement_across_8bit_wrap();
    } else {
      fprintf(stderr, "Unknown test selector: %s\n", argv[1]);
      return 2;
    }
    return 0;
  }
  CHECK(argc == 1);
  test_arp_age_across_8bit_wrap();
  test_arp_oldest_replacement_across_8bit_wrap();
  test_initialization_and_short_frames();
  test_binary_echo_and_fin();
  test_retransmission_during_busy_rx();
  test_ack_with_next_payload();
  test_segmentation_and_two_connections();
  test_tick_wrap_and_bounded_catchup();
  test_arp_aging_during_busy_rx();
  printf("All %u packet-level host test groups passed.\n", test_count);
  return 0;
}
