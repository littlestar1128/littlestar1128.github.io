param(
    [string]$Compiler = "gcc",
    [string]$BuildDirectory = ""
)

$ErrorActionPreference = "Stop"
$projectDirectory = Split-Path -Parent $PSScriptRoot
if ([string]::IsNullOrWhiteSpace($BuildDirectory)) {
    $BuildDirectory = Join-Path $PSScriptRoot ".build"
}
$null = New-Item -ItemType Directory -Force -Path $BuildDirectory
$buildPath = (Resolve-Path -LiteralPath $BuildDirectory).Path
$executable = Join-Path $buildPath "uip10-host-tests.exe"

if (-not (Get-Command $Compiler -ErrorAction SilentlyContinue)) {
    throw "C compiler not found: $Compiler. Pass -Compiler with a GCC-compatible C compiler path."
}

$compilerArguments = @(
    "-std=c99", "-O2", "-Wall", "-Wextra",
    "-Wno-unused-parameter", "-Wno-unused-but-set-variable", "-Wno-sign-compare",
    "-I$(Join-Path $projectDirectory 'config')",
    "-I$(Join-Path $projectDirectory 'core')",
    "-I$(Join-Path $projectDirectory 'port')",
    "-I$(Join-Path $projectDirectory 'app')",
    "-I$(Join-Path $projectDirectory 'third_party/uip')",
    (Join-Path $projectDirectory "tests/host_test.c"),
    (Join-Path $projectDirectory "core/uip_port.c"),
    (Join-Path $projectDirectory "app/tcp_echo.c"),
    (Join-Path $projectDirectory "third_party/uip/uip.c"),
    (Join-Path $projectDirectory "third_party/uip/uip_arp.c"),
    "-o", $executable
)

& $Compiler @compilerArguments
if ($LASTEXITCODE -ne 0) {
    throw "Compilation failed with exit code $LASTEXITCODE."
}
& $executable
if ($LASTEXITCODE -ne 0) {
    throw "Host tests failed with exit code $LASTEXITCODE."
}
