#ifndef TCP_ECHO_H
#define TCP_ECHO_H

#include "port_types.h"
#include "port_config.h"

/*
 * Included by uip-conf.h; standalone inclusion also loads the port types.
 * Do not include uip.h here: uip.h itself is loading uip-conf.h.
 * IPv4 + Ethernet + TCP without options: 14 + 20 + 20 = 54 bytes.
 */
#ifndef ECHO_BUFFER_SIZE
#define ECHO_BUFFER_SIZE (UIP_CONF_BUFFER_SIZE - 54)
#endif

#ifndef ECHO_PORT
#define ECHO_PORT 1234
#endif

#if ECHO_BUFFER_SIZE < 1 || ECHO_BUFFER_SIZE > 65535
#error "ECHO_BUFFER_SIZE must be between 1 and 65535"
#endif

#if ECHO_BUFFER_SIZE > (UIP_CONF_BUFFER_SIZE - 54)
#error "ECHO_BUFFER_SIZE exceeds the IPv4/Ethernet/TCP payload capacity"
#endif

/* One persistent buffer per TCP connection; budget this RAM per connection. */
typedef struct tcp_echo_state {
  u16_t length;       /* Total bytes kept in payload[]. */
  u16_t offset;       /* Bytes whose echo has already been acknowledged. */
  u16_t inflight;     /* Exact unacknowledged segment length, or zero. */
  u8_t payload[ECHO_BUFFER_SIZE];
} uip_tcp_appstate_t;

void tcp_echo_init(void);
void tcp_echo_appcall(void);

#endif
