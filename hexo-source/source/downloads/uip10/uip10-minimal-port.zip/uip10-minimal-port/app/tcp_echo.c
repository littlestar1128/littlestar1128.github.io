#include <string.h>
#include "uip.h"
#include "tcp_echo.h"

static void
clear_state(uip_tcp_appstate_t *state)
{
  state->length = 0;
  state->offset = 0;
  state->inflight = 0;
}

void
tcp_echo_init(void)
{
  /* Port numbers passed to uIP are in network byte order. */
  uip_listen(HTONS(ECHO_PORT));
}

void
tcp_echo_appcall(void)
{
  uip_tcp_appstate_t *state;
  u16_t received;
  u16_t remaining;
  u16_t count;
  u8_t had_newdata;

  state = &uip_conn->appstate;

  /* uip_restart() itself sets UIP_NEWDATA: snapshot the real input first. */
  had_newdata = (u8_t)(uip_newdata() != 0);

  if(uip_connected()) {
    clear_state(state);
  }

  if(uip_closed() || uip_aborted() || uip_timedout()) {
    /*
     * Stock uIP 1.0 forces FINACK on peer FIN and has no CLOSE_WAIT.
     * Client contract: send -> receive the same byte count -> close.
     * Do not shutdown the write side before reading all echoed bytes.
     * Payload + FIN in one segment cannot be echoed by this core.
     * See README for this stock uIP 1.0 half-close limitation.
     */
    clear_state(state);
    return;
  }

  /* Process the ACK first: an ACK and accepted input can share a callback. */
  if(uip_acked() && state->inflight != 0) {
    state->offset = (u16_t)(state->offset + state->inflight);
    state->inflight = 0;
    if(state->offset == state->length) {
      clear_state(state);
    }
  }

  if(had_newdata) {
    received = uip_datalen();
    if(received != 0) {
      /*
       * UIP_RECEIVE_WINDOW must be <= ECHO_BUFFER_SIZE. While occupied,
       * uip_stop() makes the core leave subsequent payload unacknowledged,
       * so the sender retains and later retransmits those bytes.
       * Never truncate accepted bytes silently if configuration is wrong.
       */
      if(state->length != 0 || received > ECHO_BUFFER_SIZE) {
        clear_state(state);
        uip_abort();
        return;
      }
      memcpy(state->payload, uip_appdata, received);
      state->length = received;
      state->offset = 0;
      state->inflight = 0;
      uip_stop();
    }
  }

  if(uip_rexmit()) {
    /* Resubmit the exact same bytes and length; keep them until ACK. */
    if(state->inflight != 0) {
      uip_send(&state->payload[state->offset], state->inflight);
    }
    return;
  }

  /* Called on new data, ACK and periodic uip_poll() events. */
  if(state->length != 0 && state->inflight == 0) {
    remaining = (u16_t)(state->length - state->offset);
    count = uip_mss();
    if(count > remaining) {
      count = remaining;
    }
    if(count != 0) {
      state->inflight = count;
      uip_send(&state->payload[state->offset], count);
    }
  }

  if(state->length == 0 && uip_stopped(uip_conn)) {
    /*
     * Every echo byte has now been acknowledged. Reopen the window.
     * uip_restart() also asks the core to send a window-update ACK.
     * Do not inspect uip_newdata()/uip_datalen() again after this call.
     */
    uip_restart();
  }
}
