# 原版 uIP 1.0 源码来源

本目录的 `uip/` 包含作者发布的 uIP 1.0 压缩包中 `uip/` 下的六个文件，保留各文件的版权及许可说明。其中 `uip_arp.c` 有下述最小修正，其余五文件保持原样。

- 发布包：<https://www.dunkels.com/adam/download/uip-1.0.tar.gz>
- 发布包 SHA256：`9a8af7043b44ad3d661e9c00e4a5b3efac678977cae07d9df73db242d26891df`
- 文件：`uip.c`、`uip.h`、`uip_arp.c`、`uip_arp.h`、`uip_arch.h`、`uipopt.h`。
- 随包文件校验值：`SHA256SUMS.txt`；上游原文件校验值：`UPSTREAM_SHA256SUMS.txt`。

这些文件来自实际 1.0 发布包。移植层、应用、板级模板和测试位于上层目录。只启用 IPv4，因此无需编译 IPv6 邻居模块；计时由移植层直接使用毫秒时基实现，无需额外引入原版 `timer.c/clock.h`。

原版 `uipopt.h` 中部分选项没有 `UIP_CONF_*` 覆盖入口，例如 `UIP_ACTIVE_OPEN`；本框架保留原值，没有定义不存在的覆盖宏。以后裁剪这类功能时须明确修改并记录核心差异。

## ARP 时间回绕修正

`arptime` 和表项时间戳都是 8 位无符号值，原版差值在 C 整型提升后可能变成负数。为使模 256 的年龄计算正确，`uip_arp.c` 中老化判断、最老表项比较和年龄赋值的三个差值表达式均显式转换为 `u8_t`。未改变协议、计时周期、ARP 表结构或 API。

完整差异见 `uip-1.0-arp-wrap.patch`。采用 10 秒周期时，计数每 42 分 40 秒回绕，此修正防止跨回绕条目不按预期过期或替换。回归测试与结果见 `../tests/README.md`。
