#ifndef PORT_CONFIG_H
#define PORT_CONFIG_H

/* TODO_HW: choose an unused address on YOUR LAN. */
#define PORT_IP_ADDR0 192
#define PORT_IP_ADDR1 168
#define PORT_IP_ADDR2 1
#define PORT_IP_ADDR3 50
#define PORT_NETMASK0 255
#define PORT_NETMASK1 255
#define PORT_NETMASK2 255
#define PORT_NETMASK3 0
#define PORT_GATEWAY0 192
#define PORT_GATEWAY1 168
#define PORT_GATEWAY2 1
#define PORT_GATEWAY3 1

/* TODO_HW: unique, locally administered unicast MAC; same value in NIC/uIP. */
#define PORT_MAC_ADDR0 0x02
#define PORT_MAC_ADDR1 0x00
#define PORT_MAC_ADDR2 0x00
#define PORT_MAC_ADDR3 0x00
#define PORT_MAC_ADDR4 0x00
#define PORT_MAC_ADDR5 0x50

/* TODO_HW: budget packet buffer + EACH connection's echo buffer + stack. */
#define UIP_CONF_BUFFER_SIZE 600
#define ECHO_BUFFER_SIZE (UIP_CONF_BUFFER_SIZE - 54)
#define ECHO_PORT 1234

/* uIP 1.0 time base: do not change these to the hardware ISR period. */
#define PORT_TCP_PERIOD_MS 500UL
#define PORT_ARP_PERIOD_MS 10000UL
#define PORT_TIMER_CATCHUP_LIMIT 4u

/* TODO_HW: set to 1 ONLY after implementing every board_port.c TODO. */
#define BOARD_PORT_IMPLEMENTED 0

#endif
