#ifndef UIP_CONF_H
#define UIP_CONF_H

#include "port_types.h"
#include "port_config.h"

/* TODO_HW: verify MCU/compiler byte order; this default suits Cortex-M. */
#define UIP_CONF_BYTE_ORDER UIP_LITTLE_ENDIAN
#define UIP_CONF_LLH_LEN 14
#define UIP_CONF_IPV6 0
#define UIP_CONF_MAX_CONNECTIONS 2
#define UIP_CONF_MAX_LISTENPORTS 1
#define UIP_CONF_ARPTAB_SIZE 4
#define UIP_CONF_RECEIVE_WINDOW ECHO_BUFFER_SIZE
#define UIP_CONF_PINGADDRCONF 0
#define UIP_CONF_UDP 0
#define UIP_CONF_UDP_CHECKSUMS 0
#define UIP_CONF_BROADCAST 0
#define UIP_CONF_LOGGING 0
#define UIP_CONF_STATISTICS 0

/* No uip.h include here: it is already loading this configuration. */
#include "tcp_echo.h"
#define UIP_APPCALL tcp_echo_appcall
typedef u8_t uip_udp_appstate_t;

#endif
