#ifndef PORT_TYPES_H
#define PORT_TYPES_H

/* TODO_HW: old compilers such as Keil C51 may lack <stdint.h>.
 * Replace these typedefs with compiler types of EXACTLY 8/16/32 bits.
 * Review C51 memory models, generic pointers and xdata separately. */
#include <stdint.h>
typedef uint8_t u8_t;
typedef uint16_t u16_t;
typedef uint32_t u32_t;
typedef uint16_t uip_stats_t;

#include <limits.h>
typedef char port_check_octet[(CHAR_BIT == 8) ? 1 : -1];
typedef char port_check_u16[(sizeof(u16_t) == 2) ? 1 : -1];
typedef char port_check_u32[(sizeof(u32_t) == 4) ? 1 : -1];
#endif
