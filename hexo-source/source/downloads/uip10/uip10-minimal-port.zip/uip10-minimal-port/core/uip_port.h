#ifndef UIP_PORT_H
#define UIP_PORT_H

/* Initialize board, tick, NIC, uIP/ARP, addresses and TCP echo listener.
 * Return 0 on success, -1 on NIC failure. */
int uip_port_init(void);

/* Sequential main-context entry points; never concurrent or from an ISR. */
void uip_port_process_rx(void);
void uip_port_process_timers(void);
void uip_port_run_once(void);

#endif
