#include <string.h>
#include "uip.h"
#include "uip_arp.h"
#include "board_port.h"
#include "port_config.h"
#include "tcp_echo.h"
#include "uip_port.h"

#if UIP_LLH_LEN != 14 || UIP_CONF_IPV6 || UIP_UDP
#error "This minimal port is for untagged Ethernet / IPv4 / TCP only"
#endif
#if PORT_TIMER_CATCHUP_LIMIT < 1
#error "PORT_TIMER_CATCHUP_LIMIT must be positive"
#endif

static u8_t initialized;
static u32_t last_tcp_ms;
static u32_t last_arp_ms;

static const u8_t local_mac[6] = {
  PORT_MAC_ADDR0, PORT_MAC_ADDR1, PORT_MAC_ADDR2,
  PORT_MAC_ADDR3, PORT_MAC_ADDR4, PORT_MAC_ADDR5
};

/* uip_len changes meaning: input Ethernet length -> IP output length ->
 * Ethernet output length after uip_arp_out(). Consume each output at once. */
static void send_frame_if_any(void)
{
  if(uip_len > 0 && uip_len <= UIP_BUFSIZE) {
    /* Official 1.0 uip_send() copies to the packet buffer; it is contiguous.
     * A different uIP fork must be checked before reusing this assumption. */
    (void)board_nic_send(uip_buf, uip_len);
  }
  uip_len = 0;
}

static void send_ip_if_any(void)
{
  if(uip_len > 0) {
    /* May replace an IP packet with an ARP request. TCP will retransmit. */
    uip_arp_out();
    send_frame_if_any();
  }
}

static u16_t read_be16(const u8_t *bytes)
{
  return (u16_t)(((u16_t)bytes[0] << 8) | bytes[1]);
}

/* Basic frame bounds before handing a packet to the old core.
 * IPv4 options, VLAN and fragmented IP are outside this minimal example. */
static int valid_ipv4_frame(u16_t frame_len)
{
  const u8_t *ip;
  u16_t ip_len;
  u16_t tcp_header_len;

  if(frame_len < 14 + 20) {
    return 0;
  }
  ip = &uip_buf[14];
  if(ip[0] != 0x45) {
    return 0;
  }
  ip_len = read_be16(&ip[2]);
  if(ip_len < 20 || ip_len > frame_len - 14) {
    return 0;
  }
  if((read_be16(&ip[6]) & 0x3fff) != 0) {
    return 0;
  }
  if(ip[9] == 6) {
    if(ip_len < 40) {
      return 0;
    }
    tcp_header_len = (u16_t)((ip[20 + 12] >> 4) * 4);
    return tcp_header_len >= 20 && tcp_header_len <= ip_len - 20;
  }
  /* The stock IPv4 core handles ICMP echo; an ICMP header needs 8 bytes. */
  return ip[9] == 1 && ip_len >= 28;
}

int uip_port_init(void)
{
  uip_ipaddr_t addr;
  struct uip_eth_addr ethaddr;

  initialized = 0;
  board_init();
  board_tick_init();
  if(board_nic_init(local_mac) < 0) {
    return -1;
  }
  uip_init();
  uip_arp_init();
  memcpy(ethaddr.addr, local_mac, sizeof(local_mac));
  /* The actual 1.0 macro accepts a struct VALUE, despite its old comment. */
  uip_setethaddr(ethaddr);
  uip_ipaddr(addr, PORT_IP_ADDR0, PORT_IP_ADDR1, PORT_IP_ADDR2, PORT_IP_ADDR3);
  uip_sethostaddr(addr);
  uip_ipaddr(addr, PORT_NETMASK0, PORT_NETMASK1, PORT_NETMASK2, PORT_NETMASK3);
  uip_setnetmask(addr);
  uip_ipaddr(addr, PORT_GATEWAY0, PORT_GATEWAY1, PORT_GATEWAY2, PORT_GATEWAY3);
  uip_setdraddr(addr);
  tcp_echo_init();
  uip_len = 0;
  last_tcp_ms = last_arp_ms = board_millis();
  initialized = 1;
  return 0;
}

void uip_port_process_rx(void)
{
  u16_t ethertype;

  if(!initialized) {
    return;
  }
  /* ONE frame per iteration bounds work even if the RX queue stays busy. */
  uip_len = board_nic_read(uip_buf, UIP_BUFSIZE);
  if(uip_len < 14 || uip_len > UIP_BUFSIZE) {
    uip_len = 0;
    return;
  }
  ethertype = read_be16(&uip_buf[12]);
  if(ethertype == UIP_ETHTYPE_IP) {
    if(!valid_ipv4_frame(uip_len)) {
      uip_len = 0;
      return;
    }
    uip_arp_ipin();
    uip_input();
    send_ip_if_any();
  } else if(ethertype == UIP_ETHTYPE_ARP && uip_len >= 42 &&
            read_be16(&uip_buf[14]) == 1 &&
            read_be16(&uip_buf[16]) == UIP_ETHTYPE_IP &&
            uip_buf[18] == 6 && uip_buf[19] == 4) {
    uip_arp_arpin();
    send_frame_if_any();
  }
  uip_len = 0;
}

void uip_port_process_timers(void)
{
  u32_t now;
  unsigned int steps;
  unsigned int conn;

  if(!initialized) {
    return;
  }
  now = board_millis(); /* board implementation MUST return an atomic value. */

  /* Unsigned subtraction handles 32-bit wrap. Advance the deadline rather
   * than assigning now, to avoid gradual drift. Bounded catch-up preserves
   * remaining timer debt for the next loop without starving RX forever. */
  steps = 0;
  while((u32_t)(now - last_tcp_ms) >= PORT_TCP_PERIOD_MS &&
        steps < PORT_TIMER_CATCHUP_LIMIT) {
    last_tcp_ms += PORT_TCP_PERIOD_MS;
    ++steps;
    for(conn = 0; conn < UIP_CONNS; ++conn) {
      uip_periodic(conn);
      send_ip_if_any();
    }
  }

  steps = 0;
  while((u32_t)(now - last_arp_ms) >= PORT_ARP_PERIOD_MS &&
        steps < PORT_TIMER_CATCHUP_LIMIT) {
    last_arp_ms += PORT_ARP_PERIOD_MS;
    ++steps;
    uip_arp_timer();
  }
}

void uip_port_run_once(void)
{
  uip_port_process_rx();
  /* Independent call: NEVER hide this in the no-RX/else branch. */
  uip_port_process_timers();
}
